package com.example.app1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class Tela2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);


       

    }

    //Metodo para voltar tela
    public void voltar(View view){

        finish();
    }

    //Metodo para carregar imagem no image view

    public void carregarImagem(View view){

        ImageView imageView = (ImageView) findViewById(R.id.imageView);
        EditText editText1 = (EditText) findViewById(R.id.editText2);





            if(editText1.getText().toString().contains("pacaembu")){

                Picasso.get().load(editText1.getText().toString()).into(imageView);
                Toast.makeText(getApplicationContext(),"Imagem pega com sucesso",
                        Toast.LENGTH_SHORT).show();

            }else{
                Toast.makeText(getApplicationContext(),"Imagem não obtida",
                        Toast.LENGTH_SHORT).show();

            }

        }


    }

