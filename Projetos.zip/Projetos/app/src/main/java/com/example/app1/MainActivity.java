package com.example.app1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    TextView textView2;
    Button button;





    // Ao apertar o botao, muda a tela
    public void trocarDeTela(Button btn){

        Intent intent = new Intent(this, Tela2Activity.class);
        startActivity(intent);



    }


    public void findWeather(View view){


        Log.i("cityName", editText.getText().toString());



        // esconder teclado ao apertar o botao
        InputMethodManager mgr =
                (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mgr.hideSoftInputFromWindow(editText.getWindowToken(), 0);





        // Para cidades que tenham espaco, como por exemplo Sao Paulo
        try {



            String encodedCityName = URLEncoder.encode(editText.getText().toString(),"UTF-8");

            DownloadTask task = new DownloadTask();
            task.execute("https://api.openweathermap.org/data/2.5/weather?q=" + editText.getText().toString()+
                    "&APPID=12dd06f94bdfebbe98d2789a33f636f7");

        }
        catch (UnsupportedEncodingException e) {

            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"Could not find weather",Toast.LENGTH_LONG);
        }





    }



    public class DownloadTask extends AsyncTask<String, Void, String>{


        @Override
        protected String doInBackground(String... strings) {  // não interage com o usuario

            String result = ""; // todo conteudo Html que tem

            URL url;

            HttpURLConnection urlConnection = null; // como abrir um navegador


            try{

                url = new URL(strings[0]); // contém apenas uma url

                urlConnection = (HttpURLConnection) url.openConnection();

                InputStream in = urlConnection.getInputStream(); // input de data

                InputStreamReader reader = new InputStreamReader(in); // ler o input de data

                int data = reader.read(); // vai seguir a data que chega, caracter por caractere
                // do HTML

                while(data != -1){

                    char current = (char) data;

                    result += current;

                    data = reader.read();
                }

                return result;

            }
            catch (Exception e){

              Toast.makeText(getApplicationContext(),"Could not find weather",Toast.LENGTH_LONG);

            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            String message = "";


            try {

                JSONObject jsonObject = new JSONObject(result);
                String weatherInfo = jsonObject.getString("weather");
                Log.i("Weather Content",weatherInfo);


                JSONArray arr = new JSONArray(weatherInfo);

                for(int i =0; i <arr.length(); i++){



                    // Informacoes do array que eu quero
                    String main = "";
                    String description = "";

                    JSONObject jsonpart = arr.getJSONObject(i); // pega todos os elementos dentro
                    // do array weather

                    main = jsonpart.getString("main");
                    description = jsonpart.getString("description");

                    if(main != "" && description != "")

                        message += main + ":" + description + "\r\n";

                        Log.i("main", main);
                        Log.i("description",description);




                }

                if(message != ""){

                    textView2.setText(message);

                }else{
                    Toast.makeText(getApplicationContext(),"Could not find weather",Toast.LENGTH_LONG);
                }
            }
            catch (JSONException e) {

                e.printStackTrace();
            }

            Log.i("Website Content",result);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        editText = (EditText) findViewById(R.id.editText);
        textView2 = (TextView) findViewById(R.id.textView2);



    }
}
